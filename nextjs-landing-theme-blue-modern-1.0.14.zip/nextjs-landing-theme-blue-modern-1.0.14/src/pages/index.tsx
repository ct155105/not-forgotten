import { Base } from '../template/Base';

const Index = () => <Base />;

export default Index;
